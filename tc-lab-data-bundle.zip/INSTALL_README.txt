TC LAB STARTER DATA BUNDLE
==========================

Contents
--------
app/src/main/assets/database/seed_catalog.json
app/src/main/assets/database/research_sources.json
app/src/main/assets/database/equipment_catalog.json
app/src/main/assets/database/calculator_catalog.json
app/src/main/assets/database/learning_modules.json

IMPORTANT
---------
This bundle adds structured starter data to Android assets. It does not yet implement the persistent SQLite/Room database, and the current home screen does not yet read these files. Those are the next coding steps.

No crop-specific protocol recipes or growth-regulator concentrations are marked approved. Research references are included for orientation and must be checked against their original sources before any values are imported into protocol records.

Repository installation
-----------------------
The existing GitHub Actions workflow must unzip this archive into the repository workspace before Gradle builds. Add a step after "Checkout repository" and before "Build APK":

- name: Install TC Lab starter data
  run: |
    if [ -f tc-lab-data-bundle.zip ]; then
      unzip -o tc-lab-data-bundle.zip -d .
    else
      echo "ERROR: tc-lab-data-bundle.zip not found at repository root"
      exit 1
    fi

Upload this ZIP to the root of the TC-Lab-Android repository with the exact filename:
tc-lab-data-bundle.zip

The ZIP archive contains the app/... paths, so extracting it at repository root puts the JSON files in app/src/main/assets/database/.

Safety and evidence rules
-------------------------
- Verify any protocol against the exact species/cultivar and source.
- Keep published evidence separate from personal measurements and calculated values.
- Confirm equipment compatibility from manufacturer documentation.
- Do not assume a pressure cooker is equivalent to a laboratory autoclave.
- Do not use plastics or sealed containers in pressure sterilization unless explicitly rated for that process.
